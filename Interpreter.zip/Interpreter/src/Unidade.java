
//TerminalExpression
public class Unidade extends Expressao {
	
	public String Um() { return "I"; }
    public String Quatro() { return "IV"; }
    public String Cinco() { return "V"; }
    public String Nove() { return "IX"; }
    public int Multiplicador() { return 1; }

}
