
//TerminalExpression
public class Dezena extends Expressao {
	
	public String Um() { return "X"; }
    public String Quatro() { return "XL"; }
    public String Cinco() { return "L"; }
    public String Nove() { return "XC"; }
    public int Multiplicador() { return 10; }

}
